
from typing import KeysView
from botcity.core import DesktopBot

class Bot(DesktopBot):
    def action(self, execution=None):
        self.execute( r'C:\Users\Public\Desktop\Small Start.lnk')
        if not self.find( "senha", matching=0.97, waiting_time=10000):
            self.not_found("senha")
        self.paste("1234")
        self.enter()
        if not self.find( "estoque", matching=0.97, waiting_time=10000):
            self.not_found("estoque")
        self.click()
        if not self.find( "clique", matching=0.97, waiting_time=10000):
            self.not_found("clique")
        if not self.find( "icms", matching=0.97, waiting_time=10000):
            self.not_found("icms")
        self.click()
        if not self.find( "mercadoria", matching=0.97, waiting_time=10000):
            self.not_found("mercadoria")
        self.click()
        self.type_keys(" {DOWN}")
        self.type_keys(" {DOWN}")
        self.type_keys(" {DOWN}")

    def not_found(self, label):
        print(f"Element not found: {label}")

if __name__ == '__main__':
    Bot.main()





